﻿import sys
import time
def view_bar(num,total):
    rate = num / total
    rate_num = int(rate * 100)
    #r = '\r %d%%' %(rate_num)
    r = '\r%s>%d%%' % ('=' * rate_num, rate_num,)
    sys.stdout.write(r)
    sys.stdout.flush

def biu():
    for x in range(12):
        print('Biu!!! '.center(150))
        time.sleep(0.1)

def sitdown():
    for x in range(12):
        print('| ~ ~ |'.center(150))
        time.sleep(0.5)

def process():
    for i in range(0, 101):
        time.sleep(0.1)
        view_bar(i, 100)
if __name__ == '__main__':
    print("春节十二响程序启动:")
    time.sleep(1)
    print("程序加载进度:")
    time.sleep(1)
    process();
    print("程序加载完毕，发动机正在启动...")
    time.sleep(1)
    print("硬件系统自检完成...")
    time.sleep(1)
    print("撞针系统自检完成...")
    time.sleep(1)
    print("发动机正在启动...")
    biu();
    print('\ ~ ~ / '.center(150))
    sitdown();
    time.sleep(0.2)
    print('/--  --\ '.center(150))
    time.sleep(0.2)
    print('/ \ / \ / \ '.center(150))
    time.sleep(0.2)
    print('|--------|'.center(150))
    time.sleep(0.2)
    print('--------------------------- '.center(150))
    time.sleep(10)
